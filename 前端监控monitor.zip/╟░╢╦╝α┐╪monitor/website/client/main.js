$.ajax({
  method:'get',
  url:'/api/list'
})
function fn() {
  let x = xx;
}
fn()

// 第八期 架构课 11月24号开课  想参加可以联系我
// 周二 周四 晚上 8-10  周五公开课 周六全天
// 在腾讯课堂